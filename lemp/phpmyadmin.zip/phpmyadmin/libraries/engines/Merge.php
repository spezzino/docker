<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * The MERGE storage engine
 *
 * @package PhpMyAdmin-Engines
 */
namespace PMA\libraries\engines;

use PMA\libraries\StorageEngine;

/**
 * The MERGE storage engine
 *
 * @package PhpMyAdmin-Engines
 */
class Merge extends StorageEngine
{
}

